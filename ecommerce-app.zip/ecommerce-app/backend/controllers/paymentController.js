const axios = require("axios");
const Product = require("../models/Product");
const Order = require("../models/Order");

const PAYPAL_BASE = "https://api-m.sandbox.paypal.com";

// ── Helper: obtain a short-lived PayPal access token ─────────
const getAccessToken = async () => {
  const response = await axios.post(
    `${PAYPAL_BASE}/v1/oauth2/token`,
    "grant_type=client_credentials",
    {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      auth: {
        username: process.env.PAYPAL_CLIENT_ID,
        password: process.env.PAYPAL_CLIENT_SECRET,
      },
    }
  );
  return response.data.access_token;
};

// GET /api/payments/config
// Returns the PayPal client ID so the frontend can load the SDK
const getPayPalConfig = (req, res) => {
  res.json({ clientId: process.env.PAYPAL_CLIENT_ID });
};

// POST /api/payments/create-order
// Creates a PayPal order for the given product and returns the PayPal orderID
const createPayPalOrder = async (req, res, next) => {
  try {
    const { productId, quantity = 1 } = req.body;

    // Fetch product details from DB
    const product = await Product.findById(productId);
    if (!product) {
      const err = new Error("Product not found");
      err.statusCode = 404;
      return next(err);
    }

    const total = (product.price * quantity).toFixed(2);
    const accessToken = await getAccessToken();

    const response = await axios.post(
      `${PAYPAL_BASE}/v2/checkout/orders`,
      {
        intent: "CAPTURE",
        purchase_units: [
          {
            reference_id: product._id.toString(),
            description: product.name,
            amount: {
              currency_code: "EUR",
              value: total,
            },
          },
        ],
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    res.json({ orderID: response.data.id });
  } catch (err) {
    next(err);
  }
};

// POST /api/payments/capture-order
// Captures the approved PayPal payment and saves the order to MongoDB
const capturePayPalOrder = async (req, res, next) => {
  try {
    const { orderID, productId, quantity = 1 } = req.body;

    const product = await Product.findById(productId);
    if (!product) {
      const err = new Error("Product not found");
      err.statusCode = 404;
      return next(err);
    }

    const accessToken = await getAccessToken();

    // Capture the payment with PayPal
    const captureRes = await axios.post(
      `${PAYPAL_BASE}/v2/checkout/orders/${orderID}/capture`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    const capture = captureRes.data;
    const captureDetail =
      capture.purchase_units[0]?.payments?.captures?.[0];

    // Decrement product stock
    await Product.findByIdAndUpdate(productId, {
      $inc: { stock: -quantity },
    });

    // Persist the order in MongoDB
    const order = await Order.create({
      paypalOrderId: orderID,
      paypalPaymentId: captureDetail?.id || orderID,
      items: [
        {
          product: productId,
          productName: product.name,
          quantity,
          unitPrice: product.price,
        },
      ],
      total: product.price * quantity,
      customerEmail:
        capture.payer?.email_address || "sandbox-buyer@example.com",
      status: "completed",
    });

    res.json({ success: true, order });
  } catch (err) {
    next(err);
  }
};

module.exports = { getPayPalConfig, createPayPalOrder, capturePayPalOrder };
