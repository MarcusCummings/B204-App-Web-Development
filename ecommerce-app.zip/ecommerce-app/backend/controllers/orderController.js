const Order = require("../models/Order");

// GET /api/orders  — return all orders, most recent first
const getAllOrders = async (req, res, next) => {
  try {
    const orders = await Order.find()
      .populate("items.product", "name imageUrl")
      .sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) {
    next(err);
  }
};

// GET /api/orders/:id  — single order by ID
const getOrderById = async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id).populate(
      "items.product",
      "name imageUrl"
    );
    if (!order) {
      const err = new Error("Order not found");
      err.statusCode = 404;
      return next(err);
    }
    res.json(order);
  } catch (err) {
    next(err);
  }
};

module.exports = { getAllOrders, getOrderById };
