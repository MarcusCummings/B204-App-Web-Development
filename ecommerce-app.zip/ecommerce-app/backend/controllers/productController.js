const Product = require("../models/Product");

// GET /api/products  — list all products
const getAllProducts = async (req, res, next) => {
  try {
    const products = await Product.find().sort({ createdAt: -1 });
    res.json(products);
  } catch (err) {
    next(err);
  }
};

// GET /api/products/search?name=query  — search by name (case-insensitive)
const searchProducts = async (req, res, next) => {
  try {
    const { name } = req.query;
    if (!name) return res.json([]);

    const products = await Product.find({
      name: { $regex: name, $options: "i" },
    });
    res.json(products);
  } catch (err) {
    next(err);
  }
};

// GET /api/products/:id  — single product by ID
const getProductById = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      const err = new Error("Product not found");
      err.statusCode = 404;
      return next(err);
    }
    res.json(product);
  } catch (err) {
    next(err);
  }
};

// POST /api/products  — create a new product
const createProduct = async (req, res, next) => {
  try {
    const { name, description, price, category, stock, imageUrl } = req.body;
    const product = await Product.create({
      name,
      description,
      price,
      category,
      stock,
      imageUrl,
    });
    res.status(201).json(product);
  } catch (err) {
    next(err);
  }
};

// PUT /api/products/:id  — update a product
const updateProduct = async (req, res, next) => {
  try {
    const product = await Product.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!product) {
      const err = new Error("Product not found");
      err.statusCode = 404;
      return next(err);
    }
    res.json(product);
  } catch (err) {
    next(err);
  }
};

// DELETE /api/products/:id  — remove a product
const deleteProduct = async (req, res, next) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) {
      const err = new Error("Product not found");
      err.statusCode = 404;
      return next(err);
    }
    res.json({ message: "Product deleted successfully" });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getAllProducts,
  searchProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
};
