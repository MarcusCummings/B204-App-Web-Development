// Global Express error-handling middleware.
// Must have exactly 4 parameters so Express recognises it as an error handler.
const errorHandler = (err, req, res, next) => {
  const statusCode = err.statusCode || 500;

  // Mongoose validation errors
  if (err.name === "ValidationError") {
    const messages = Object.values(err.errors).map((e) => e.message);
    return res.status(400).json({ error: messages.join(", ") });
  }

  // Mongoose bad ObjectId
  if (err.name === "CastError") {
    return res.status(400).json({ error: "Invalid ID format" });
  }

  console.error(`[ERROR ${statusCode}]`, err.message);
  res.status(statusCode).json({ error: err.message || "Server error" });
};

module.exports = errorHandler;
