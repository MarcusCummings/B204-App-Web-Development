/**
 * Seed script — run once to populate the database with sample products.
 * Usage (inside Docker): docker exec nexshop_app node backend/seed.js
 * Usage (local):          node backend/seed.js
 */

require("dotenv").config();
const mongoose = require("mongoose");
const Product  = require("./models/Product");

const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/nexshop";

const sampleProducts = [
  {
    name:        "Sony WH-1000XM5 Headphones",
    description: "Industry-leading noise cancellation with up to 30 hours battery life and crystal-clear hands-free calling.",
    price:       279.99,
    category:    "Electronics",
    stock:       18,
    imageUrl:    "https://placehold.co/600x450/1e293b/93c5fd?text=Sony+Headphones",
  },
  {
    name:        "Mechanical Keyboard TKL",
    description: "Tenkeyless layout with Cherry MX Red switches, RGB backlight and aluminium frame. Perfect for programmers.",
    price:       89.99,
    category:    "Electronics",
    stock:       35,
    imageUrl:    "https://placehold.co/600x450/1e293b/93c5fd?text=Mech+Keyboard",
  },
  {
    name:        "Clean Code by Robert C. Martin",
    description: "A handbook of agile software craftsmanship. Every programmer should read this book at least once.",
    price:       34.99,
    category:    "Books",
    stock:       50,
    imageUrl:    "https://placehold.co/600x450/1e3a8a/93c5fd?text=Clean+Code",
  },
  {
    name:        "You Don't Know JS (Series)",
    description: "A series of books diving deep into the core mechanisms of the JavaScript language.",
    price:       59.99,
    category:    "Books",
    stock:       22,
    imageUrl:    "https://placehold.co/600x450/1e3a8a/93c5fd?text=YDKJS",
  },
  {
    name:        "Running Shoes — Adidas Ultraboost",
    description: "Responsive Boost midsole with Primeknit upper. Ideal for long-distance running and everyday training.",
    price:       149.99,
    category:    "Sports",
    stock:       12,
    imageUrl:    "https://placehold.co/600x450/166534/dcfce7?text=Ultraboost",
  },
  {
    name:        "Yoga Mat Pro",
    description: "Extra thick 6mm non-slip yoga mat with alignment lines. Eco-friendly TPE material.",
    price:       39.99,
    category:    "Sports",
    stock:       40,
    imageUrl:    "https://placehold.co/600x450/166534/dcfce7?text=Yoga+Mat",
  },
  {
    name:        "Slim Fit Merino Wool Sweater",
    description: "Premium 100% merino wool sweater. Breathable, soft, and perfect for layering in cold weather.",
    price:       79.99,
    category:    "Clothing",
    stock:       25,
    imageUrl:    "https://placehold.co/600x450/713f12/fef9c3?text=Merino+Sweater",
  },
  {
    name:        "Smart LED Desk Lamp",
    description: "Touch-control LED lamp with 5 colour temperatures, USB-C charging port and memory function.",
    price:       44.99,
    category:    "Home",
    stock:       5,
    imageUrl:    "https://placehold.co/600x450/1e293b/93c5fd?text=Desk+Lamp",
  },
  {
    name:        "French Press Coffee Maker",
    description: "Stainless steel 1L French press with double-wall insulation to keep coffee hot for hours.",
    price:       29.99,
    category:    "Home",
    stock:       33,
    imageUrl:    "https://placehold.co/600x450/7c3f1e/fef0e0?text=French+Press",
  },
  {
    name:        "USB-C Hub 7-in-1",
    description: "7-port hub: 4K HDMI, 100W PD, 3× USB-A, SD and microSD slots. Compact aluminium design.",
    price:       49.99,
    category:    "Electronics",
    stock:       0,
    imageUrl:    "https://placehold.co/600x450/1e293b/93c5fd?text=USB-C+Hub",
  },
];

async function seed() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log("✅  Connected to MongoDB");

    await Product.deleteMany({});
    console.log("🗑️   Cleared existing products");

    const inserted = await Product.insertMany(sampleProducts);
    console.log(`✅  Seeded ${inserted.length} products`);
  } catch (err) {
    console.error("❌  Seed failed:", err.message);
  } finally {
    await mongoose.disconnect();
    console.log("🔌  Disconnected from MongoDB");
    process.exit(0);
  }
}

seed();
