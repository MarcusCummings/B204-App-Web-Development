const mongoose = require("mongoose");

const orderItemSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Product",
    required: true,
  },
  productName: { type: String, required: true },
  quantity:    { type: Number, required: true, min: 1 },
  unitPrice:   { type: Number, required: true },
});

const orderSchema = new mongoose.Schema(
  {
    items:           { type: [orderItemSchema], required: true },
    total:           { type: Number, required: true },
    customerEmail:   { type: String, default: "sandbox@example.com" },
    paypalOrderId:   { type: String, required: true, unique: true },
    paypalPaymentId: { type: String },
    status: {
      type: String,
      enum: ["pending", "completed", "failed"],
      default: "pending",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Order", orderSchema);
