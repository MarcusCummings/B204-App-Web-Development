const express = require("express");
const router = express.Router();
const {
  getPayPalConfig,
  createPayPalOrder,
  capturePayPalOrder,
} = require("../controllers/paymentController");

router.get("/config", getPayPalConfig);
router.post("/create-order", createPayPalOrder);
router.post("/capture-order", capturePayPalOrder);

module.exports = router;
