// ── Products listing page ─────────────────────────────────

const grid        = document.getElementById("products-grid");
const searchInput = document.getElementById("search-input");
const searchBtn   = document.getElementById("search-btn");
const resultInfo  = document.getElementById("result-info");

// Load all products on first paint
async function loadProducts() {
  renderSkeletons("products-grid", 8);
  try {
    const products = await ProductAPI.getAll();
    renderGrid(products, "All Products");
  } catch (err) {
    grid.innerHTML = `<div class="alert alert-error">Failed to load products: ${err.message}</div>`;
  }
}

// Search products by name via API
async function handleSearch() {
  const query = searchInput.value.trim();
  if (!query) return loadProducts();

  renderSkeletons("products-grid", 4);
  try {
    const products = await ProductAPI.search(query);
    renderGrid(products, `Results for "${query}"`);
  } catch (err) {
    grid.innerHTML = `<div class="alert alert-error">Search error: ${err.message}</div>`;
  }
}

// Render the product grid and update result count text
function renderGrid(products, label = "") {
  resultInfo.textContent = `${label} — ${products.length} item${products.length !== 1 ? "s" : ""}`;

  if (!products.length) {
    grid.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1">
        <div class="empty-icon">🔍</div>
        <h3>No products found</h3>
        <p>Try a different search term or browse all products.</p>
        <button class="btn btn-primary" onclick="searchInput.value='';loadProducts()">View all</button>
      </div>`;
    return;
  }

  grid.innerHTML = products.map(buildProductCard).join("");
}

// Bind search events
searchBtn.addEventListener("click", handleSearch);
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") handleSearch();
});

// Clear search on empty input
searchInput.addEventListener("input", () => {
  if (!searchInput.value.trim()) loadProducts();
});

loadProducts();
