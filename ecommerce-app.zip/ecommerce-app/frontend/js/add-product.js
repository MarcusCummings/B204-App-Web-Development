// ── Add Product Page ──────────────────────────────────────

const form        = document.getElementById("add-product-form");
const submitBtn   = document.getElementById("submit-btn");
const previewImg  = document.getElementById("img-preview");
const imgUrlInput = document.getElementById("imageUrl");

// Live image URL preview
imgUrlInput?.addEventListener("input", () => {
  const url = imgUrlInput.value.trim();
  if (url) {
    previewImg.src = url;
    previewImg.style.display = "block";
    previewImg.onerror = () => {
      previewImg.src = "https://placehold.co/400x300?text=Invalid+URL";
    };
  } else {
    previewImg.style.display = "none";
  }
});

// Form submission
form?.addEventListener("submit", async (e) => {
  e.preventDefault();

  const data = {
    name:        document.getElementById("name").value.trim(),
    description: document.getElementById("description").value.trim(),
    price:       parseFloat(document.getElementById("price").value),
    category:    document.getElementById("category").value,
    stock:       parseInt(document.getElementById("stock").value, 10),
    imageUrl:    document.getElementById("imageUrl").value.trim() ||
                 "https://placehold.co/400x300?text=No+Image",
  };

  // Basic client-side validation
  if (!data.name || !data.description || isNaN(data.price) || isNaN(data.stock)) {
    showAlert("Please fill in all required fields.", "error");
    return;
  }
  if (data.price < 0) {
    showAlert("Price cannot be negative.", "error");
    return;
  }

  submitBtn.disabled     = true;
  submitBtn.textContent  = "Saving…";

  try {
    await ProductAPI.create(data);
    showAlert("✅ Product added successfully! Redirecting…", "success");
    form.reset();
    previewImg.style.display = "none";
    setTimeout(() => (location.href = "products.html"), 1800);
  } catch (err) {
    showAlert("Error: " + err.message, "error");
  } finally {
    submitBtn.disabled    = false;
    submitBtn.textContent = "Add Product";
  }
});
