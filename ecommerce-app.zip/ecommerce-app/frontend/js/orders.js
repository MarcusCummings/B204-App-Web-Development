// ── Order History Page ────────────────────────────────────

async function loadOrders() {
  const container = document.getElementById("orders-container");

  try {
    const orders = await OrderAPI.getAll();

    if (!orders.length) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">📦</div>
          <h3>No orders yet</h3>
          <p>Complete a purchase to see it listed here.</p>
          <a href="products.html" class="btn btn-primary">Browse Products</a>
        </div>`;
      return;
    }

    // Update summary counters
    document.getElementById("total-orders").textContent    = orders.length;
    document.getElementById("completed-orders").textContent =
      orders.filter((o) => o.status === "completed").length;
    document.getElementById("total-revenue").textContent   =
      formatPrice(orders.reduce((sum, o) => sum + o.total, 0));

    // Build table rows
    const rows = orders.map((order) => {
      const items = order.items
        .map((i) => `${i.productName} ×${i.quantity}`)
        .join(", ");

      return `
        <tr>
          <td><span class="order-id">${order.paypalOrderId}</span></td>
          <td>${formatDate(order.createdAt)}</td>
          <td>${items}</td>
          <td><strong>${formatPrice(order.total)}</strong></td>
          <td>${order.customerEmail}</td>
          <td><span class="badge badge-${order.status}">${order.status}</span></td>
        </tr>`;
    });

    container.innerHTML = `
      <div class="orders-table-wrapper">
        <table class="orders-table">
          <thead>
            <tr>
              <th>PayPal Order ID</th>
              <th>Date</th>
              <th>Items</th>
              <th>Total</th>
              <th>Customer</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>${rows.join("")}</tbody>
        </table>
      </div>`;
  } catch (err) {
    container.innerHTML = `<div class="alert alert-error">Failed to load orders: ${err.message}</div>`;
  }
}

loadOrders();
