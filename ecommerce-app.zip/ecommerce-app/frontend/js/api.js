// Base URL for all API calls (same origin — Express serves both frontend and API)
const API_BASE = "/api";

// Generic fetch wrapper with JSON parsing and error propagation
async function apiFetch(endpoint, options = {}) {
  const response = await fetch(`${API_BASE}${endpoint}`, {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || `HTTP ${response.status}`);
  }
  return data;
}

// ── Product endpoints ─────────────────────────────────────
const ProductAPI = {
  getAll:  ()           => apiFetch("/products"),
  search:  (name)       => apiFetch(`/products/search?name=${encodeURIComponent(name)}`),
  getById: (id)         => apiFetch(`/products/${id}`),
  create:  (data)       => apiFetch("/products", { method: "POST", body: JSON.stringify(data) }),
  update:  (id, data)   => apiFetch(`/products/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete:  (id)         => apiFetch(`/products/${id}`, { method: "DELETE" }),
};

// ── Order endpoints ───────────────────────────────────────
const OrderAPI = {
  getAll:  () => apiFetch("/orders"),
  getById: (id) => apiFetch(`/orders/${id}`),
};

// ── Payment endpoints ─────────────────────────────────────
const PaymentAPI = {
  getConfig:    ()     => apiFetch("/payments/config"),
  createOrder:  (data) => apiFetch("/payments/create-order", { method: "POST", body: JSON.stringify(data) }),
  captureOrder: (data) => apiFetch("/payments/capture-order", { method: "POST", body: JSON.stringify(data) }),
};
