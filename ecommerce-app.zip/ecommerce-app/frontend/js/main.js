// ── Shared utilities ──────────────────────────────────────

// Format a number as EUR currency
function formatPrice(amount) {
  return new Intl.NumberFormat("de-DE", {
    style: "currency",
    currency: "EUR",
  }).format(amount);
}

// Format an ISO date string to a readable locale string
function formatDate(isoString) {
  return new Date(isoString).toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// Truncate text to a given character limit
function truncate(text, limit = 80) {
  return text && text.length > limit ? text.slice(0, limit) + "…" : text;
}

// Return appropriate stock badge HTML
function stockBadge(stock) {
  if (stock <= 0)  return `<span class="stock-badge no-stock">Out of stock</span>`;
  if (stock <= 5)  return `<span class="stock-badge low-stock">Only ${stock} left</span>`;
  return               `<span class="stock-badge in-stock">In stock</span>`;
}

// Show a temporary alert at the top of #alert-area
function showAlert(message, type = "info") {
  const area = document.getElementById("alert-area");
  if (!area) return;
  area.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
  setTimeout(() => { area.innerHTML = ""; }, 4000);
}

// Highlight the active nav link based on the current page filename
function setActiveNav() {
  const page = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-links a").forEach((link) => {
    const href = link.getAttribute("href");
    if (href === page || (page === "" && href === "index.html")) {
      link.classList.add("active");
    }
  });
}

// Render a row of skeleton loader cards
function renderSkeletons(containerId, count = 4) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = Array(count)
    .fill('<div class="skeleton skeleton-card"></div>')
    .join("");
}

// Build product card HTML (used on listing and search pages)
function buildProductCard(product) {
  const price = formatPrice(product.price);
  const badge = stockBadge(product.stock);
  return `
    <article class="product-card" onclick="location.href='product-detail.html?id=${product._id}'">
      <img src="${product.imageUrl}" alt="${product.name}" loading="lazy"
           onerror="this.src='https://placehold.co/400x300?text=No+Image'">
      <div class="product-card-body">
        <p class="product-card-category">${product.category}</p>
        <h3 class="product-card-name">${product.name}</h3>
        <p class="product-card-desc">${truncate(product.description)}</p>
      </div>
      <div class="product-card-footer">
        <span class="product-price">${price}</span>
        ${badge}
      </div>
    </article>`;
}

// Run active-nav highlight on every page load
document.addEventListener("DOMContentLoaded", setActiveNav);
