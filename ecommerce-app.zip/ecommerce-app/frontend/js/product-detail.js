// ── Product Detail Page ───────────────────────────────────

const params    = new URLSearchParams(location.search);
const productId = params.get("id");

if (!productId) location.href = "products.html";

let currentProduct = null;

// Load the PayPal JS SDK dynamically using the client ID from our backend
async function loadPayPalSDK() {
  const { clientId } = await PaymentAPI.getConfig();
  return new Promise((resolve, reject) => {
    if (document.getElementById("paypal-sdk")) return resolve();
    const script = document.createElement("script");
    script.id  = "paypal-sdk";
    script.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=EUR`;
    script.onload  = resolve;
    script.onerror = () => reject(new Error("Failed to load PayPal SDK"));
    document.head.appendChild(script);
  });
}

// Render PayPal buttons for the current product + selected quantity
function renderPayPalButtons(product) {
  const container = document.getElementById("paypal-button-container");
  container.innerHTML = '<div class="spinner"></div>';

  // Clear previous instance
  if (window.paypalButtonInstance) {
    window.paypalButtonInstance.close();
  }

  window.paypalButtonInstance = window.paypal.Buttons({
    style: { layout: "vertical", color: "blue", shape: "rect", label: "pay" },

    // Step 1: Create a PayPal order on our backend
    createOrder: async () => {
      const qty = parseInt(document.getElementById("quantity").value, 10) || 1;
      const { orderID } = await PaymentAPI.createOrder({
        productId: product._id,
        quantity:  qty,
      });
      return orderID;
    },

    // Step 2: Capture the payment after buyer approves
    onApprove: async (data) => {
      const qty = parseInt(document.getElementById("quantity").value, 10) || 1;
      try {
        const result = await PaymentAPI.captureOrder({
          orderID:   data.orderID,
          productId: product._id,
          quantity:  qty,
        });

        if (result.success) {
          showSuccessModal(result.order);
        }
      } catch (err) {
        showAlert("Payment capture failed: " + err.message, "error");
      }
    },

    // Step 3: Handle buyer cancellation
    onCancel: () => {
      showAlert("Payment cancelled. You can try again anytime.", "info");
    },

    // Step 4: Handle unexpected errors
    onError: (err) => {
      console.error("PayPal error:", err);
      showAlert("A PayPal error occurred. Please try again.", "error");
    },
  });

  window.paypalButtonInstance.render("#paypal-button-container");
}

// Show the success confirmation modal
function showSuccessModal(order) {
  document.getElementById("modal-order-id").textContent   = order.paypalOrderId;
  document.getElementById("modal-total").textContent      = formatPrice(order.total);
  document.getElementById("modal-overlay").classList.add("show");
}

// Close the modal
document.getElementById("close-modal")?.addEventListener("click", () => {
  document.getElementById("modal-overlay").classList.remove("show");
  location.href = "orders.html";
});

// Main: fetch product data then build the page
async function loadProductDetail() {
  try {
    const product = await ProductAPI.getById(productId);
    currentProduct = product;

    // Populate DOM
    document.title = `${product.name} — NexShop`;
    document.getElementById("product-name").textContent      = product.name;
    document.getElementById("product-category").textContent  = product.category;
    document.getElementById("product-price").textContent     = formatPrice(product.price);
    document.getElementById("product-desc").textContent      = product.description;
    document.getElementById("product-stock").textContent     = product.stock;
    document.getElementById("product-img").src               = product.imageUrl;
    document.getElementById("product-img").alt               = product.name;
    document.getElementById("breadcrumb-name").textContent   = product.name;

    // Disable checkout if out of stock
    if (product.stock <= 0) {
      document.getElementById("payment-section").innerHTML =
        '<div class="alert alert-error">⚠️ This product is currently out of stock.</div>';
      return;
    }

    // Set quantity max
    document.getElementById("quantity").max = product.stock;

    // Load PayPal SDK and render buttons
    await loadPayPalSDK();
    renderPayPalButtons(product);
  } catch (err) {
    document.getElementById("product-detail-wrapper").innerHTML =
      `<div class="alert alert-error">Could not load product: ${err.message}</div>`;
  }
}

loadProductDetail();
